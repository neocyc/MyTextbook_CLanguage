/*
*this is my first progarm project.
*test by book.
*name : College Blackjack Team.
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
	char card_name[3];
	int count=0;
	do{	

		puts("Enter the card_name:");
		scanf("%2s", card_name);

/* if else example */
/*
	int val = 10;
	if(card_name[0] == 'K'){
		val = 10;	
	}
	else if(card_name[0] == 'Q'){
		val = 10;
	}
	else if(card_name[0] == 'J'){
		val = 10;
	}
	else if(card_name[0] == 'A'){
		val = 11;
	}
	else{
		val = atoi(card_name);	
	}
*/

/* switch example */

		int val = 10;
		switch(card_name[0]){
			case 'K':
			case 'Q':
			case 'J':
				val = 10;
				break;
			case 'A':
				val = 11;
				break;
			case 'X':
				continue;
			default:
				val = atoi(card_name);
				if((val<1)||(val>10)){
					puts("input error!pleae try again");
					continue;
				}

		}

/* check the value is 3 to 6 */
		if((val>2)&&(val<7)){
			puts("Count has gone up");
			count++;
		}
/* check the card was 10,J,Q, or K */
		else if(val==10){
			puts("Count has gone down");
			count--;
		}
		
		printf("Current count: %i \n",count);	
	
	}while(card_name[0]!='X');

	printf("Game over");
	return 0;
}
