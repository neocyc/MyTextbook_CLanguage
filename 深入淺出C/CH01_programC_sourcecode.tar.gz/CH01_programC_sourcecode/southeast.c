#include <stdio.h>

void go_south_east(int* lat,int* lon)
{
	*lat = *lat -1;
	*lon = *lon +1;
	printf("avast! now at:[%p, %p] \n",&lat,&lon);
	//int la,lo;
	//la = &lat;
	//lo = &lon;
	//printf("avast! addres at:[%p, %p] \n",la,lo);
}

int main()
{
	int latitude = 32;
	int longitude = -64;
	
	go_south_east(&latitude,&longitude);
	printf("avast! now at:[%i, %i] \n",latitude,longitude);
	printf("avast! now at:[%p, %p] \n",&latitude,&longitude);	

	//int lati,longi;
	//lati = &latitude;
	//longi = &longitude;
	//printf("avast! addres at:[%p, %p] \n",lati,longi);
	
return 0;
}
