#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
	char *feeds[]={"http://rss.cnn.com/rss/edition_entertainment.rss","http://rss.cnn.com/rss/edition_technology.rss","http://rss.cnn.com/rss/cnn_freevideo.rss"};
	int times = 3;
	char *phrase = argv[1];
	int i;
	int count=50;

	for(i=0;i<times;i++){
		char var[255];
		sprintf(var,"RSS_FEED=%s",feeds[i]);
		char *vars[]={var,NULL};
/*		
		printf("%i\n",i);
		if(execle("/usr/bin/python","/usr/bin/python","./rssgossip.py",phrase,NULL,vars)==-1){
			fprintf(stderr,"Can't run script: %s\n",strerror(errno));
			return 1;
		}
		int p=i+1;
		printf("%i\n",p);
*/
		
		printf("Work RSS_FEED ID: %i\n",i);

		pid_t pid = fork();		
		//printf("process of pid: %i\n",pid);		
		int fp=pid;
		printf("process of pid: %i\n",fp);		

		if(pid == -1){
			fprintf(stderr,"Can't fork process: %s\n",strerror(errno));
			return 1;
		}		
		
		if(!pid){	
			int p=pid+1;			
			printf("subprocess staring: %i\n",p);
			count=count-1;
			printf("subprocess of order: %i\n",count);

			if(execle("/usr/bin/python","/usr/bin/python","./rssgossip.py",phrase,NULL,vars)==-1){
				fprintf(stderr,"Can't run script: %s\n",strerror(errno));
				return 1;
			}								
		}		
		
		fp=i;		
		printf("process ending: %i\n",fp);

		printf("Finish RSS_FEED ID: %i\n",i);	
	}

 return 0;
}
