#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
 char *my_env[]={"JUICE=peach and apple",NULL}; 
 
 execle("diner_info","diner_info","4",NULL,my_env); 
 
// if 'excle' run succeess,then stop run following 
 puts("Dude - the diner_info code must be busted");
 
//puts(strerror(errno=3)); 
 puts(strerror(3)); 

//---------------------------------------------------//

 execl("/home/ifconfig","/home/ifconfig",NULL);
 
// if 'excl' run succeess,then stop run following 
 puts("Dude - the ifconfig process must be busted");
 
//puts(strerror(errno=2)); 
 puts(strerror(2)); 

 execlp("ifconfig","ifconfig",NULL);

// if 'exclp' run succeess,then stop run following 
 puts("Dude - the ifconfig process must be busted");

 return 0;
}
